    // for (i = 0; i < r1; i++)
    // {
    //     for (j = 0; j < c2; j++)

    //     printf("\n");
    // }