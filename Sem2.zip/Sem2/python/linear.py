import matplotlib.pyplot as plt
import numpy as np

ypoints = np.array([3,8,1,10])
plt.plot(ypoints,linestyle="dotted")
plt.show()


# import pandas as pd
# data = pd.read_csv("/Users/krishant/Documents/Learning/Study/1-Clg/MCA/Sem2/python/linear_reg.csv")
# # df = pd.read_csv("https://media.geeksforgeeks.org/wp-content/uploads/nba.csv")  
# print(data)

# y=data['GPA']
# x1=data['SAT']
# plt.xlabel('SAT',fontsize=20)
# plt.xlabel('GPA',fontsize=20)

# plt.show()

