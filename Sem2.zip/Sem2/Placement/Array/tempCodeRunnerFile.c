    // for (int i = 0; i < p; i++)
    // {
    //     // printf("%d ", inter[i]);
    // }