import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;

class gui_p {
    public static void main(String args[]) {
        A ob1 = new A();
    }
}

class A extends JFrame {
    public A() {
        setLayout(new FlowLayout());
        JLabel l1 = new JLabel("Krishant");
        JLabel l2 = new JLabel("Siya");
        add(l1);
        add(l2);
        setVisible(true);
        setSize(400, 500);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
