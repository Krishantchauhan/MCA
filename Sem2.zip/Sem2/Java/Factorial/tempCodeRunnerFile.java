   // int i = 1;
        // while (i <= n) {
        //     f = f * i;
        //     i++;
        // }